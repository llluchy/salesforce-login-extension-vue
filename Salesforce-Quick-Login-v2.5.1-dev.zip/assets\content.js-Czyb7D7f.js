(function(){window.__sfContentInjected||(window.__sfContentInjected=!0);let r=null,d=null,w=!1,C=0,M=0,I=null;chrome.runtime.onMessage.addListener((t,o,c)=>{if(t.action==="startAreaSelect")return I=t.dataUrl,z(),c({success:!0}),!0});function z(){if(r)return;r=document.createElement("div"),r.id="sf-ql-overlay",r.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.4);
    z-index: 2147483646;
    cursor: crosshair;
  `,d=document.createElement("div"),d.id="sf-ql-selection",d.style.cssText=`
    position: fixed;
    border: 2px solid #00A1E0;
    background: rgba(0, 161, 224, 0.1);
    pointer-events: none;
    z-index: 2147483647;
    display: none;
    box-sizing: border-box;
  `;const t=document.createElement("div");t.id="sf-ql-tip",t.textContent="拖拽选择二维码区域，按 ESC 取消",t.style.cssText=`
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.75);
    color: white;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    pointer-events: none;
  `,r.appendChild(d),r.appendChild(t),document.body.appendChild(r),w=!1,r.addEventListener("mousedown",D),r.addEventListener("mousemove",B),r.addEventListener("mouseup",S),document.addEventListener("keydown",T)}function D(t){t.button===0&&(t.preventDefault(),w=!0,C=t.clientX,M=t.clientY,d.style.display="block",d.style.left=C+"px",d.style.top=M+"px",d.style.width="0px",d.style.height="0px")}function B(t){if(!w)return;t.preventDefault();const o=Math.max(0,Math.min(window.innerWidth,t.clientX)),c=Math.max(0,Math.min(window.innerHeight,t.clientY)),n=Math.min(C,o),p=Math.min(M,c),m=Math.abs(o-C),f=Math.abs(c-M);d.style.left=n+"px",d.style.top=p+"px",d.style.width=m+"px",d.style.height=f+"px"}async function S(t){if(!w)return;t.preventDefault(),w=!1;const o=d.getBoundingClientRect(),c=o.left,n=o.top,p=o.width,m=o.height;if(L(),p<10||m<10){chrome.runtime.sendMessage({action:"areaCancelled",reason:"too small"});return}try{const f=await _(I,c,n,p,m);chrome.runtime.sendMessage({action:"areaSelected",dataUrl:f})}catch(f){chrome.runtime.sendMessage({action:"areaCancelled",reason:f.message})}}function T(t){t.key==="Escape"&&(L(),chrome.runtime.sendMessage({action:"areaCancelled",reason:"user cancelled"}))}function L(){w=!1,r&&r.parentNode&&r.parentNode.removeChild(r),r=null,d=null,document.removeEventListener("keydown",T)}function _(t,o,c,n,p){return new Promise((m,f)=>{const e=new Image;e.onload=()=>{const i=e.width/window.innerWidth,s=e.height/window.innerHeight,u=document.createElement("canvas");u.width=n*i,u.height=p*s,u.getContext("2d").drawImage(e,o*i,c*s,n*i,p*s,0,0,u.width,u.height),m(u.toDataURL("image/png"))},e.onerror=()=>f(new Error("图片加载失败")),e.src=t})}(function(){if(window.__sfPasskeyBridgeInjected)return;window.__sfPasskeyBridgeInjected=!0;const t="[CT]";function o(e,i){window.postMessage({source:"sf-extension",requestId:e,data:i},"*")}window.addEventListener("message",async e=>{if(!e.data||e.data.source!=="sf-page-world")return;const i=e.data.action,s=e.data.requestId;if(i==="sessionGet"){try{const h=await chrome.runtime.sendMessage({action:"__sf_sessionGet",keys:e.data.data.keys||e.data.keys});o(s,h||{})}catch(h){console.error(`${t} [sessionGet] 失败:`,h.message),o(s,{})}return}if(i==="sf:passkeyGet"||i==="sf:passkeyCreate"){let y=function(g){x||a||(x=!0,a=!0,l&&(clearInterval(l),l=null),f(),c.delete(s),console.warn(`${t} [${h}] 立即 fallback 系统 Passkey: ${g||""}`),o(s,{fallback:!0}))},E=function(){x||a||chrome.runtime.sendMessage({action:"bg:ping"}).then(g=>{x||a||g&&g.open&&(chrome.runtime.sendMessage({action:h,requestId:s,data:b}).catch(k=>{y(`send ${h} 失败: ${(k==null?void 0:k.message)||String(k)}`)}),a=!0,l&&(clearInterval(l),l=null))}).catch(g=>{y(`bg:ping 失败: ${(g==null?void 0:g.message)||String(g)}`)})};var u=y,v=E;const h=i,b=e.data.data;let x=!1,a=!1,l=null;E();const $=setTimeout(()=>{x||a||(m(),l=setInterval(E,3e3))},2e3);c.set(s,()=>{x=!0,clearTimeout($),l&&clearInterval(l),f()});return}console.error(`${t} [message] 未处理的消息: ${i}`)}),chrome.runtime.onMessage.addListener((e,i)=>{if(e.action!=="sf:passkeyResult")return;const s=c.get(e.requestId);s&&(s(),c.delete(e.requestId)),o(e.requestId,e.data)});const c=new Map;let n=null,p=null;function m(){if(n)return;if(!document.getElementById("sf-bubble-style")){const y=document.createElement("style");y.id="sf-bubble-style",y.textContent=`
        @keyframes sf-bubble-in {
          from { opacity: 0; transform: translateX(20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes sf-bubble-out {
          from { opacity: 1; transform: translateX(0); }
          to { opacity: 0; transform: translateX(20px); }
        }
        #sf-passkey-bubble.sf-closing {
          animation: sf-bubble-out 0.3s ease forwards;
        }
      `,document.head.appendChild(y)}n=document.createElement("div"),n.id="sf-passkey-bubble",n.style.cssText=`
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 2147483647;
      background: #fff;
      border: 1px solid #1976d2;
      border-radius: 10px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.18);
      padding: 0;
      width: 300px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 13px;
      color: #333;
      overflow: hidden;
      animation: sf-bubble-in 0.3s ease;
    `;const e=document.createElement("div");e.style.cssText=`
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 14px;
      background: linear-gradient(135deg, #1565c0, #1976d2);
      color: #fff;
    `;const i=chrome.runtime.getURL("icons/icon48.png");e.innerHTML=`
      <div style="width:22px;height:22px;border-radius:4px;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
        <img src="${i}" style="width:16px;height:16px;" alt="ext"/>
      </div>
      <span style="font-weight:600;font-size:13px;">Salesforce Quick Login</span>
    `;const s=document.createElement("div");s.style.cssText="padding: 12px 14px;";const u=document.createElement("div");u.textContent="需要打开扩展面板",u.style.cssText="font-weight: 600; color: #0d47a1; margin-bottom: 6px; font-size: 14px;";const v=document.createElement("div");v.textContent="网页正在请求 Passkey 验证，请打开扩展侧边栏以完成验证。",v.style.cssText="color: #555; line-height: 1.5; margin-bottom: 10px;";const h=document.createElement("div");h.style.cssText=`
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 10px;
      background: #f0f7ff;
      border-radius: 6px;
      margin-bottom: 10px;
    `,h.innerHTML=`
      <div style="position:relative;width:28px;height:28px;flex-shrink:0;">
        <svg width="28" height="28" viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg">
          <rect x="2" y="4" width="24" height="18" rx="2" fill="#e3f2fd" stroke="#1976d2" stroke-width="1"/>
          <rect x="2" y="4" width="24" height="4" rx="2" fill="#bbdefb"/>
          <circle cx="5.5" cy="6" r="0.8" fill="#1976d2"/>
          <circle cx="8" cy="6" r="0.8" fill="#1976d2"/>
          <circle cx="10.5" cy="6" r="0.8" fill="#1976d2"/>
        </svg>
        <div style="position:absolute;top:-3px;right:-3px;width:12px;height:12px;border-radius:50%;background:#ff6f00;border:1.5px solid #fff;box-shadow:0 0 4px rgba(255,111,0,0.5);"></div>
      </div>
      <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">
        <path d="M3 8 L13 8 M9 4 L13 8 L9 12" stroke="#1976d2" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <div style="width:28px;height:28px;flex-shrink:0;border-radius:6px;background:#fff;border:1.5px solid #1976d2;display:flex;align-items:center;justify-content:center;">
        <img src="${i}" style="width:18px;height:18px;" alt="ext"/>
      </div>
      <span style="font-size:11px;color:#1976d2;font-weight:500;">点击图标</span>
    `,s.appendChild(u),s.appendChild(v),s.appendChild(h);const b=document.createElement("div");b.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 14px;
      background: #fafafa;
      border-top: 1px solid #eee;
    `;const x=document.createElement("span");x.style.cssText="font-size: 11px; color: #999;";const a=document.createElement("button");a.textContent="关闭",a.style.cssText=`
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 12px;
      color: #1976d2;
      font-weight: 500;
      padding: 2px 8px;
    `,a.onmouseover=()=>{a.style.color="#0d47a1"},a.onmouseout=()=>{a.style.color="#1976d2"},a.onclick=f,b.appendChild(x),b.appendChild(a),n.appendChild(e),n.appendChild(s),n.appendChild(b),document.body.appendChild(n);let l=30;x.textContent=`${l}s 后自动关闭`,p=setInterval(()=>{l--,l<=0?f():x.textContent=`${l}s 后自动关闭`},1e3)}function f(){if(p&&(clearInterval(p),p=null),n){n.classList.add("sf-closing");const e=n;setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},300),n=null}}console.log(`${t} ========== 桥接模块初始化完成 (v4.1) ==========`)})();
})()
